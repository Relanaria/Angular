export interface UserLogin {
    email: string;
    firstName: string;
    lastName:string,
    password: string,
    country: string,
    city: string,
    profileImg: string
    accessToken: string; 
_id: string;
}
