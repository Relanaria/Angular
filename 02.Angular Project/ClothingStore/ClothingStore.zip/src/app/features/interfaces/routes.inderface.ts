export interface Routes {
    [kidsClothes: string]: string,
    womanClothes: string,
    menClothes: string
}